 # Basic description
Browser based register application that interacts with a PostgreSQL database. Implemented in Java with Spring Boot and JPA. Edited in Visual Studio Code.  
  
The application defaults to port 8080.

To start from the IDE press F5 to run. This will open the debug and run view. You will need to create a launch configuration which Visual Studio Code will help you with.  

 # Landing page (list available products)
`https://uarkregappjava.herokuapp.com/`