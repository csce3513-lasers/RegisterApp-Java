package edu.uark.registerapp.commands;

public interface VoidCommandInterface {
	void execute();
}
