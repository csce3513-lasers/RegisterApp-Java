package edu.uark.registerapp.commands;

public interface ResultCommandInterface<T> {
	T execute();
}
