//some basic java script functions to go to diffrent pages needs full url



function GoToUnderConstruction()
{
	//used to go to the under construction page need full url
	location.assign("/underConstruction.html");
}


function goToProductListing()
{
	location.assign("/productListing.html");
}


function goToNewEmployee()
{
	location.assign("/employeeDetail.html");
}